import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyMediumBluegray900 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.blueGray900,
      );
  static get bodyMediumff2f2f2f => theme.textTheme.bodyMedium!.copyWith(
        color: Color(0XFF2F2F2F),
      );
  static get bodyMediumff303030 => theme.textTheme.bodyMedium!.copyWith(
        color: Color(0XFF303030),
      );
  static get bodyMediumff8b8b8b => theme.textTheme.bodyMedium!.copyWith(
        color: Color(0XFF8B8B8B),
      );
  static get bodySmallBluegray400 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.blueGray400,
      );
  static get bodySmallGray500 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.gray500,
      );
  // Label text style
  static get labelMediumYellow900 => theme.textTheme.labelMedium!.copyWith(
        color: appTheme.yellow900,
      );
}

extension on TextStyle {
  TextStyle get roboto {
    return copyWith(
      fontFamily: 'Roboto',
    );
  }
}
