import 'package:assignment/presentation/documents_container_screen/documents_container_screen.dart';
import 'package:assignment/presentation/documents_container_screen/binding/documents_container_binding.dart';
import 'package:assignment/presentation/transaction_documents_screen/transaction_documents_screen.dart';
import 'package:assignment/presentation/transaction_documents_screen/binding/transaction_documents_binding.dart';
import 'package:assignment/presentation/transaction_documents_detail_page_screen/transaction_documents_detail_page_screen.dart';
import 'package:assignment/presentation/transaction_documents_detail_page_screen/binding/transaction_documents_detail_page_binding.dart';
import 'package:assignment/presentation/joining_documents_screen/joining_documents_screen.dart';
import 'package:assignment/presentation/joining_documents_screen/binding/joining_documents_binding.dart';
import 'package:assignment/presentation/team_documents_screen/team_documents_screen.dart';
import 'package:assignment/presentation/team_documents_screen/binding/team_documents_binding.dart';
import 'package:assignment/presentation/tax_documents_screen/tax_documents_screen.dart';
import 'package:assignment/presentation/tax_documents_screen/binding/tax_documents_binding.dart';
import 'package:assignment/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:assignment/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String documentsPage = '/documents_page';

  static const String documentsContainerScreen = '/documents_container_screen';

  static const String transactionDocumentsScreen =
      '/transaction_documents_screen';

  static const String transactionDocumentsDetailPageScreen =
      '/transaction_documents_detail_page_screen';

  static const String joiningDocumentsScreen = '/joining_documents_screen';

  static const String teamDocumentsScreen = '/team_documents_screen';

  static const String taxDocumentsScreen = '/tax_documents_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: documentsContainerScreen,
      page: () => DocumentsContainerScreen(),
      bindings: [
        DocumentsContainerBinding(),
      ],
    ),
    GetPage(
      name: transactionDocumentsScreen,
      page: () => TransactionDocumentsScreen(),
      bindings: [
        TransactionDocumentsBinding(),
      ],
    ),
    GetPage(
      name: transactionDocumentsDetailPageScreen,
      page: () => TransactionDocumentsDetailPageScreen(),
      bindings: [
        TransactionDocumentsDetailPageBinding(),
      ],
    ),
    GetPage(
      name: joiningDocumentsScreen,
      page: () => JoiningDocumentsScreen(),
      bindings: [
        JoiningDocumentsBinding(),
      ],
    ),
    GetPage(
      name: teamDocumentsScreen,
      page: () => TeamDocumentsScreen(),
      bindings: [
        TeamDocumentsBinding(),
      ],
    ),
    GetPage(
      name: taxDocumentsScreen,
      page: () => TaxDocumentsScreen(),
      bindings: [
        TaxDocumentsBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => DocumentsContainerScreen(),
      bindings: [
        DocumentsContainerBinding(),
      ],
    )
  ];
}
