class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Common images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgNavHome = '$imagePath/img_nav_home.svg';

  static String imgNavDocuments = '$imagePath/img_nav_documents.svg';

  static String imgEye = '$imagePath/img_eye.svg';

  static String imgFilepdf = '$imagePath/img_filepdf.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
