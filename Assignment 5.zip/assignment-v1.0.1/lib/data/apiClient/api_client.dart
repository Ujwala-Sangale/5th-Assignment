import 'package:assignment/core/app_export.dart';

class ApiClient extends GetConnect {}
