final Map<String, String> enUs = {
  // Documents Screen
  "lbl_tax_document": "Tax Document",
  "msg_joining_document": "Joining Document",

  // Documents - Container Screen
  "lbl_home": "Home",

  // Transaction Documents Screen
  "lbl_08_16_23": "08/16/23",
  "lbl_08_25_23": "08/25/23",
  "lbl_09_04_23": "09/04/23",
  "lbl_closed_date": "Closed Date\n",
  "lbl_settled_on": "Settled On\n",
  "msg_12782_150th_avenue": "12782, 150th Avenue South,\nNew York, CA. 56345",
  "msg_4858_rosemont": "4858, Rosemont Avenue,\nMelbourne, Florida 32901",
  "msg_closed_date_08_25_23": "Closed Date\n08/25/23",
  "msg_settled_on_08_16_23": "Settled On\n08/16/23",
  "msg_settled_on_09_04_23": "Settled On\n09/04/23",
  "msg_transaction_documents": "Transaction Documents",
  "msg_transaction_id_235678": "Transaction Id #235678",

  // Transaction Documents- Detail Page Screen
  "lbl_235678": "#235678",
  "lbl_document_name": "Document Name",
  "lbl_transaction_id": "Transaction ID",
  "msg_2715_ash_dr_san": "2715 Ash Dr. San Jose, South Dakota 83475",
  "msg_license_document_pdf": "License Document.pdf",
  "msg_transaction_address": "Transaction Address",

  // Joining Documents Screen
  "msg_joining_documents": "Joining Documents",

  // Tax Documents Screen
  "lbl_1099_pdf": "1099.pdf", "lbl_tax_documents": "Tax Documents",
  "lbl_w9_pdf": "w9.pdf", "msg_tax_statement_pdf": "Tax statement.pdf",

  // Common String
  "lbl_15_mb": "15 MB",
  "lbl_cheque_pdf": "Cheque.pdf",
  "lbl_documents": "Documents",
  "lbl_team_documents": "Team Documents",
  "msg_ica_document_pdf": "ICA Document.pdf",
  "msg_settlement_document_pdf": "Settlement Document.pdf",
  "msg_transaction_document": "Transaction Document",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
