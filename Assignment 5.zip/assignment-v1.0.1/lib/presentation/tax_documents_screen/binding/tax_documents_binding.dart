import '../controller/tax_documents_controller.dart';
import 'package:get/get.dart';

/// A binding class for the TaxDocumentsScreen.
///
/// This class ensures that the TaxDocumentsController is created when the
/// TaxDocumentsScreen is first loaded.
class TaxDocumentsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => TaxDocumentsController());
  }
}
