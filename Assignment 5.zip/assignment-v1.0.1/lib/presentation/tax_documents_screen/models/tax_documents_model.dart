import '../../../core/app_export.dart';
import 'fileviewer1_item_model.dart';

/// This class defines the variables used in the [tax_documents_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class TaxDocumentsModel {
  Rx<List<Fileviewer1ItemModel>> fileviewer1ItemList = Rx([
    Fileviewer1ItemModel(fileName: "1099.pdf".obs, fileSize: "15 MB".obs),
    Fileviewer1ItemModel(fileName: "w9.pdf".obs, fileSize: "15 MB".obs),
    Fileviewer1ItemModel(
        fileName: "Tax statement.pdf".obs, fileSize: "15 MB".obs)
  ]);
}
