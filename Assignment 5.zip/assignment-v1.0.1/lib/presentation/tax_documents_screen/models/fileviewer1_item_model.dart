import '../../../core/app_export.dart';

/// This class is used in the [fileviewer1_item_widget] screen.
class Fileviewer1ItemModel {
  Fileviewer1ItemModel({
    this.fileName,
    this.fileSize,
    this.id,
  }) {
    fileName = fileName ?? Rx("1099.pdf");
    fileSize = fileSize ?? Rx("15 MB");
    id = id ?? Rx("");
  }

  Rx<String>? fileName;

  Rx<String>? fileSize;

  Rx<String>? id;
}
