import 'package:assignment/core/app_export.dart';
import 'package:assignment/presentation/tax_documents_screen/models/tax_documents_model.dart';

/// A controller class for the TaxDocumentsScreen.
///
/// This class manages the state of the TaxDocumentsScreen, including the
/// current taxDocumentsModelObj
class TaxDocumentsController extends GetxController {
  Rx<TaxDocumentsModel> taxDocumentsModelObj = TaxDocumentsModel().obs;
}
