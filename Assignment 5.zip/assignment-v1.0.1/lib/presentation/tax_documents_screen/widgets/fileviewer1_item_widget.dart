import '../controller/tax_documents_controller.dart';
import '../models/fileviewer1_item_model.dart';
import 'package:assignment/core/app_export.dart';
import 'package:assignment/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class Fileviewer1ItemWidget extends StatelessWidget {
  Fileviewer1ItemWidget(
    this.fileviewer1ItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  Fileviewer1ItemModel fileviewer1ItemModelObj;

  var controller = Get.find<TaxDocumentsController>();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(bottom: 21.v),
          child: CustomIconButton(
            height: 34.adaptSize,
            width: 34.adaptSize,
            padding: EdgeInsets.all(7.h),
            child: CustomImageView(
              imagePath: ImageConstant.imgFilepdf,
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(
            left: 12.h,
            bottom: 17.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Obx(
                () => Text(
                  fileviewer1ItemModelObj.fileName!.value,
                  style: TextStyle(
                    color: appTheme.blueGray900,
                    fontSize: 16.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
              SizedBox(height: 3.v),
              Obx(
                () => Text(
                  fileviewer1ItemModelObj.fileSize!.value,
                  style: TextStyle(
                    color: appTheme.blueGray400,
                    fontSize: 14.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ],
          ),
        ),
        Spacer(),
        CustomImageView(
          imagePath: ImageConstant.imgEye,
          height: 24.adaptSize,
          width: 24.adaptSize,
          margin: EdgeInsets.only(
            top: 6.v,
            bottom: 26.v,
          ),
        ),
      ],
    );
  }
}
