import '../controller/documents_container_controller.dart';
import 'package:get/get.dart';

/// A binding class for the DocumentsContainerScreen.
///
/// This class ensures that the DocumentsContainerController is created when the
/// DocumentsContainerScreen is first loaded.
class DocumentsContainerBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => DocumentsContainerController());
  }
}
