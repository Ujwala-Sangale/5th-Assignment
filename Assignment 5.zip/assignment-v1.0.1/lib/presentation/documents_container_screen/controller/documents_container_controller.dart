import 'package:assignment/core/app_export.dart';
import 'package:assignment/presentation/documents_container_screen/models/documents_container_model.dart';

/// A controller class for the DocumentsContainerScreen.
///
/// This class manages the state of the DocumentsContainerScreen, including the
/// current documentsContainerModelObj
class DocumentsContainerController extends GetxController {
  Rx<DocumentsContainerModel> documentsContainerModelObj =
      DocumentsContainerModel().obs;

  @override
  void onReady() {
    Future.delayed(const Duration(milliseconds: 3000), () {
      Get.offNamed(
        AppRoutes.transactionDocumentsScreen,
      );
    });
  }
}
