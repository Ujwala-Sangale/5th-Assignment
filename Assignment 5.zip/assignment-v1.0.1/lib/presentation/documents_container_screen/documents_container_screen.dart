import 'controller/documents_container_controller.dart';
import 'package:assignment/core/app_export.dart';
import 'package:assignment/presentation/documents_page/documents_page.dart';
import 'package:assignment/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

class DocumentsContainerScreen extends GetWidget<DocumentsContainerController> {
  const DocumentsContainerScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Navigator(
                key: Get.nestedKey(1),
                initialRoute: AppRoutes.documentsPage,
                onGenerateRoute: (routeSetting) => GetPageRoute(
                    page: () => getCurrentPage(routeSetting.name!),
                    transition: Transition.noTransition)),
            bottomNavigationBar: _buildBottomBar()));
  }

  /// Section Widget
  Widget _buildBottomBar() {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Get.toNamed(getCurrentRoute(type), id: 1);
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Documents:
        return AppRoutes.documentsPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.documentsPage:
        return DocumentsPage();
      default:
        return DefaultWidget();
    }
  }
}
