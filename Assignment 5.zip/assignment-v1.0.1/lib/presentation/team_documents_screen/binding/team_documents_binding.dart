import '../controller/team_documents_controller.dart';
import 'package:get/get.dart';

/// A binding class for the TeamDocumentsScreen.
///
/// This class ensures that the TeamDocumentsController is created when the
/// TeamDocumentsScreen is first loaded.
class TeamDocumentsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => TeamDocumentsController());
  }
}
