import '../../../core/app_export.dart';

/// This class is used in the [fileviewer_item_widget] screen.
class FileviewerItemModel {
  FileviewerItemModel({
    this.fileName,
    this.fileSize,
    this.id,
  }) {
    fileName = fileName ?? Rx("Cheque.pdf");
    fileSize = fileSize ?? Rx("15 MB");
    id = id ?? Rx("");
  }

  Rx<String>? fileName;

  Rx<String>? fileSize;

  Rx<String>? id;
}
