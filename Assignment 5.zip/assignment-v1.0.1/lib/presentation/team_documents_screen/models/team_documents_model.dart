import '../../../core/app_export.dart';
import 'fileviewer_item_model.dart';

/// This class defines the variables used in the [team_documents_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class TeamDocumentsModel {
  Rx<List<FileviewerItemModel>> fileviewerItemList = Rx([
    FileviewerItemModel(fileName: "Cheque.pdf".obs, fileSize: "15 MB".obs),
    FileviewerItemModel(
        fileName: "Settlement Document.pdf".obs, fileSize: "15 MB".obs),
    FileviewerItemModel(fileName: "ICA Document.pdf".obs, fileSize: "15 MB".obs)
  ]);
}
