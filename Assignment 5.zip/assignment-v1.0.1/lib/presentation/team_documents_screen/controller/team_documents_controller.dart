import 'package:assignment/core/app_export.dart';
import 'package:assignment/presentation/team_documents_screen/models/team_documents_model.dart';

/// A controller class for the TeamDocumentsScreen.
///
/// This class manages the state of the TeamDocumentsScreen, including the
/// current teamDocumentsModelObj
class TeamDocumentsController extends GetxController {
  Rx<TeamDocumentsModel> teamDocumentsModelObj = TeamDocumentsModel().obs;
}
