import 'controller/documents_controller.dart';
import 'models/documents_model.dart';
import 'package:assignment/core/app_export.dart';
import 'package:assignment/widgets/app_bar/appbar_title.dart';
import 'package:assignment/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class DocumentsPage extends StatelessWidget {
  DocumentsPage({Key? key}) : super(key: key);

  DocumentsController controller =
      Get.put(DocumentsController(DocumentsModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 19.h, vertical: 20.v),
                child: Column(children: [
                  _buildTransactionDocument(
                      dynamicText: "msg_joining_document".tr,
                      onTapTransactionDocument: () {
                        onTapTransactionDocument();
                      },
                      navigatetoTextdo: () {
                        navigatetoJoinig();
                      }),
                  SizedBox(height: 16.v),
                  Divider(),
                  SizedBox(height: 20.v),
                  _buildTransactionDocument(
                      dynamicText: "msg_transaction_document".tr,
                      navigatetoTextdo: () {
                        navigatetoTextdo();
                      }),
                  SizedBox(height: 16.v),
                  Divider(),
                  SizedBox(height: 20.v),
                  _buildTransactionDocument(
                      dynamicText: "lbl_team_documents".tr,
                      navigatetoTextdo: () {
                        navigatetoText();
                      }),
                  SizedBox(height: 16.v),
                  Divider(),
                  SizedBox(height: 20.v),
                  _buildTransactionDocument(
                      dynamicText: "lbl_tax_document".tr,
                      onTapTransactionDocument: () {
                        onTapTransactionDocument1();
                      }),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        centerTitle: true,
        title: AppbarTitle(text: "lbl_documents".tr),
        styleType: Style.bgFill);
  }

  /// Common widget
  Widget _buildTransactionDocument({
    required String dynamicText,
    Function? onTapTransactionDocument,
    Function? navigatetoTextdo,
  }) {
    return GestureDetector(
        onTap: () {
          onTapTransactionDocument!.call();
        },
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          GestureDetector(onTap: () {
            navigatetoTextdo!.call();
          }),
          Padding(
              padding: EdgeInsets.only(top: 1.v, bottom: 3.v),
              child: Text(dynamicText,
                  style: TextStyle(
                      color: appTheme.blueGray900,
                      fontSize: 16.fSize,
                      fontFamily: 'Roboto',
                      fontWeight: FontWeight.w400))),
          CustomImageView(
              imagePath: ImageConstant.imgArrowLeft, height: 24.v, width: 25.h)
        ]));
  }

  /// Navigates to the joiningDocumentsScreen when the action is triggered.
  onTapTransactionDocument() {
    Get.toNamed(
      AppRoutes.joiningDocumentsScreen,
    );
  }

  /// Navigates to the joiningDocumentsScreen when the action is triggered.
  navigatetoJoinig() {
    Get.toNamed(
      AppRoutes.joiningDocumentsScreen,
    );
  }

  /// Navigates to the transactionDocumentsScreen when the action is triggered.
  navigatetoTextdo() {
    Get.toNamed(
      AppRoutes.transactionDocumentsScreen,
    );
  }

  /// Navigates to the taxDocumentsScreen when the action is triggered.
  navigatetoText() {
    Get.toNamed(
      AppRoutes.taxDocumentsScreen,
    );
  }

  /// Navigates to the taxDocumentsScreen when the action is triggered.
  onTapTransactionDocument1() {
    Get.toNamed(
      AppRoutes.taxDocumentsScreen,
    );
  }
}
