import 'package:assignment/core/app_export.dart';
import 'package:assignment/presentation/documents_page/models/documents_model.dart';

/// A controller class for the DocumentsPage.
///
/// This class manages the state of the DocumentsPage, including the
/// current documentsModelObj
class DocumentsController extends GetxController {
  DocumentsController(this.documentsModelObj);

  Rx<DocumentsModel> documentsModelObj;
}
