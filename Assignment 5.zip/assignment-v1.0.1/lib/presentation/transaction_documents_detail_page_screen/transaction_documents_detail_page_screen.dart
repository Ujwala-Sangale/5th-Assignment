import 'controller/transaction_documents_detail_page_controller.dart';
import 'package:assignment/core/app_export.dart';
import 'package:assignment/widgets/app_bar/appbar_leading_image.dart';
import 'package:assignment/widgets/app_bar/appbar_title.dart';
import 'package:assignment/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class TransactionDocumentsDetailPageScreen
    extends GetWidget<TransactionDocumentsDetailPageController> {
  const TransactionDocumentsDetailPageScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 19.h, vertical: 21.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildEmailAddress(
                          name: "msg_transaction_address".tr,
                          maxHawkins: "msg_2715_ash_dr_san".tr),
                      SizedBox(height: 21.v),
                      _buildEmailAddress(
                          name: "lbl_transaction_id".tr,
                          maxHawkins: "lbl_235678".tr),
                      SizedBox(height: 21.v),
                      Text("lbl_document_name".tr,
                          style: TextStyle(
                              color: appTheme.gray500,
                              fontSize: 12.fSize,
                              fontFamily: 'Roboto',
                              fontWeight: FontWeight.w400)),
                      SizedBox(height: 9.v),
                      _buildFrame(documentText: "msg_license_document_pdf".tr),
                      SizedBox(height: 16.v),
                      _buildFrame(documentText: "msg_license_document_pdf".tr),
                      SizedBox(height: 16.v),
                      _buildFrame(documentText: "msg_license_document_pdf".tr),
                      SizedBox(height: 5.v)
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 36.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 10.v, bottom: 10.v),
            onTap: () {
              onTapArrowLeft();
            }),
        centerTitle: true,
        title: AppbarTitle(text: "msg_transaction_document".tr),
        styleType: Style.bgFill);
  }

  /// Common widget
  Widget _buildEmailAddress({
    required String name,
    required String maxHawkins,
  }) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(name,
          style: TextStyle(
              color: appTheme.blueGray400,
              fontSize: 12.fSize,
              fontFamily: 'Roboto',
              fontWeight: FontWeight.w400)),
      SizedBox(height: 7.v),
      Text(maxHawkins,
          style: TextStyle(
              color: appTheme.blueGray900,
              fontSize: 16.fSize,
              fontFamily: 'Roboto',
              fontWeight: FontWeight.w400)),
      SizedBox(height: 18.v),
      Divider(color: appTheme.gray300)
    ]);
  }

  /// Common widget
  Widget _buildFrame({required String documentText}) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Padding(
          padding: EdgeInsets.symmetric(vertical: 2.v),
          child: Text(documentText,
              style: TextStyle(
                  color: appTheme.blueGray900,
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400))),
      CustomImageView(
          imagePath: ImageConstant.imgEye,
          height: 24.adaptSize,
          width: 24.adaptSize)
    ]);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }
}
