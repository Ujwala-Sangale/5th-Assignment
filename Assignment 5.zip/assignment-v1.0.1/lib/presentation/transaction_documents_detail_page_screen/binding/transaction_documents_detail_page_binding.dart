import '../controller/transaction_documents_detail_page_controller.dart';
import 'package:get/get.dart';

/// A binding class for the TransactionDocumentsDetailPageScreen.
///
/// This class ensures that the TransactionDocumentsDetailPageController is created when the
/// TransactionDocumentsDetailPageScreen is first loaded.
class TransactionDocumentsDetailPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => TransactionDocumentsDetailPageController());
  }
}
