import 'package:assignment/core/app_export.dart';
import 'package:assignment/presentation/transaction_documents_detail_page_screen/models/transaction_documents_detail_page_model.dart';

/// A controller class for the TransactionDocumentsDetailPageScreen.
///
/// This class manages the state of the TransactionDocumentsDetailPageScreen, including the
/// current transactionDocumentsDetailPageModelObj
class TransactionDocumentsDetailPageController extends GetxController {
  Rx<TransactionDocumentsDetailPageModel>
      transactionDocumentsDetailPageModelObj =
      TransactionDocumentsDetailPageModel().obs;
}
