import 'package:assignment/core/app_export.dart';
import 'package:assignment/presentation/transaction_documents_screen/models/transaction_documents_model.dart';

/// A controller class for the TransactionDocumentsScreen.
///
/// This class manages the state of the TransactionDocumentsScreen, including the
/// current transactionDocumentsModelObj
class TransactionDocumentsController extends GetxController {
  Rx<TransactionDocumentsModel> transactionDocumentsModelObj =
      TransactionDocumentsModel().obs;
}
