import '../transaction_documents_screen/widgets/listofdocuments_item_widget.dart';
import 'controller/transaction_documents_controller.dart';
import 'models/listofdocuments_item_model.dart';
import 'package:assignment/core/app_export.dart';
import 'package:assignment/widgets/app_bar/appbar_leading_image.dart';
import 'package:assignment/widgets/app_bar/appbar_title.dart';
import 'package:assignment/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class TransactionDocumentsScreen
    extends GetWidget<TransactionDocumentsController> {
  const TransactionDocumentsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Padding(
                padding: EdgeInsets.only(left: 20.h, top: 20.v, right: 20.h),
                child: Obx(() => ListView.separated(
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    separatorBuilder: (context, index) {
                      return SizedBox(height: 20.v);
                    },
                    itemCount: controller.transactionDocumentsModelObj.value
                        .listofdocumentsItemList.value.length,
                    itemBuilder: (context, index) {
                      ListofdocumentsItemModel model = controller
                          .transactionDocumentsModelObj
                          .value
                          .listofdocumentsItemList
                          .value[index];
                      return ListofdocumentsItemWidget(model);
                    })))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 36.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 10.v, bottom: 10.v),
            onTap: () {
              onTapArrowLeft();
            }),
        centerTitle: true,
        title: AppbarTitle(text: "msg_transaction_documents".tr),
        styleType: Style.bgFill);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }
}
