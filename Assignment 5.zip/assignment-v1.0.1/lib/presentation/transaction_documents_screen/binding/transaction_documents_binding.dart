import '../controller/transaction_documents_controller.dart';
import 'package:get/get.dart';

/// A binding class for the TransactionDocumentsScreen.
///
/// This class ensures that the TransactionDocumentsController is created when the
/// TransactionDocumentsScreen is first loaded.
class TransactionDocumentsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => TransactionDocumentsController());
  }
}
