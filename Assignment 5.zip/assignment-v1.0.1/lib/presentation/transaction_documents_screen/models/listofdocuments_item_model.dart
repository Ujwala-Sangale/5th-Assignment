import '../../../core/app_export.dart';

/// This class is used in the [listofdocuments_item_widget] screen.
class ListofdocumentsItemModel {
  ListofdocumentsItemModel({
    this.address,
    this.transactionId,
    this.id,
  }) {
    address = address ?? Rx("12782, 150th Avenue South,\nNew York, CA. 56345");
    transactionId = transactionId ?? Rx("Transaction Id #235678");
    id = id ?? Rx("");
  }

  Rx<String>? address;

  Rx<String>? transactionId;

  Rx<String>? id;
}
