import '../../../core/app_export.dart';
import 'listofdocuments_item_model.dart';

/// This class defines the variables used in the [transaction_documents_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class TransactionDocumentsModel {
  Rx<List<ListofdocumentsItemModel>> listofdocumentsItemList = Rx([
    ListofdocumentsItemModel(
        address: "12782, 150th Avenue South,\nNew York, CA. 56345".obs,
        transactionId: "Transaction Id #235678".obs),
    ListofdocumentsItemModel(
        address: "4858, Rosemont Avenue,\nMelbourne, Florida 32901".obs,
        transactionId: "Transaction Id #235678".obs),
    ListofdocumentsItemModel(
        address: "12782, 150th Avenue South,\nNew York, CA. 56345".obs,
        transactionId: "Transaction Id #235678".obs)
  ]);
}
