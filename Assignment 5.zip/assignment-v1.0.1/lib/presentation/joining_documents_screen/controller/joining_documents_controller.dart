import 'package:assignment/core/app_export.dart';
import 'package:assignment/presentation/joining_documents_screen/models/joining_documents_model.dart';

/// A controller class for the JoiningDocumentsScreen.
///
/// This class manages the state of the JoiningDocumentsScreen, including the
/// current joiningDocumentsModelObj
class JoiningDocumentsController extends GetxController {
  Rx<JoiningDocumentsModel> joiningDocumentsModelObj =
      JoiningDocumentsModel().obs;
}
