import '../../../core/app_export.dart';
import 'joiningdocuments_item_model.dart';

/// This class defines the variables used in the [joining_documents_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class JoiningDocumentsModel {
  Rx<List<JoiningdocumentsItemModel>> joiningdocumentsItemList = Rx([
    JoiningdocumentsItemModel(
        fileName: "Cheque.pdf".obs, fileSize: "15 MB".obs),
    JoiningdocumentsItemModel(
        fileName: "Settlement Document.pdf".obs, fileSize: "15 MB".obs),
    JoiningdocumentsItemModel(
        fileName: "ICA Document.pdf".obs, fileSize: "15 MB".obs)
  ]);
}
