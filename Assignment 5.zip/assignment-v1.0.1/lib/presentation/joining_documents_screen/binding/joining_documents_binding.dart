import '../controller/joining_documents_controller.dart';
import 'package:get/get.dart';

/// A binding class for the JoiningDocumentsScreen.
///
/// This class ensures that the JoiningDocumentsController is created when the
/// JoiningDocumentsScreen is first loaded.
class JoiningDocumentsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => JoiningDocumentsController());
  }
}
