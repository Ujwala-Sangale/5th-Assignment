import '../joining_documents_screen/widgets/joiningdocuments_item_widget.dart';
import 'controller/joining_documents_controller.dart';
import 'models/joiningdocuments_item_model.dart';
import 'package:assignment/core/app_export.dart';
import 'package:assignment/widgets/app_bar/appbar_leading_image.dart';
import 'package:assignment/widgets/app_bar/appbar_title.dart';
import 'package:assignment/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class JoiningDocumentsScreen extends GetWidget<JoiningDocumentsController> {
  const JoiningDocumentsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Padding(
                padding: EdgeInsets.only(left: 20.h, top: 22.v, right: 20.h),
                child: Obx(() => ListView.separated(
                    physics: BouncingScrollPhysics(),
                    shrinkWrap: true,
                    separatorBuilder: (context, index) {
                      return Padding(
                          padding: EdgeInsets.symmetric(vertical: 11.0.v),
                          child: SizedBox(
                              width: 335.h,
                              child: Divider(
                                  height: 1.v,
                                  thickness: 1.v,
                                  color: appTheme.blueGray90001
                                      .withOpacity(0.05))));
                    },
                    itemCount: controller.joiningDocumentsModelObj.value
                        .joiningdocumentsItemList.value.length,
                    itemBuilder: (context, index) {
                      JoiningdocumentsItemModel model = controller
                          .joiningDocumentsModelObj
                          .value
                          .joiningdocumentsItemList
                          .value[index];
                      return JoiningdocumentsItemWidget(model);
                    })))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 36.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 10.v, bottom: 10.v),
            onTap: () {
              onTapArrowLeft();
            }),
        centerTitle: true,
        title: AppbarTitle(text: "msg_joining_documents".tr),
        styleType: Style.bgFill);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }
}
